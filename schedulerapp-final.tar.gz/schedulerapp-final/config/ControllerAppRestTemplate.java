package com.ubs.bigid.schedulerapp.config;

import com.ubs.bigid.schedulerapp.security.ServiceTokenProvider;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Component;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

/**
 * A BigID REST template to handle BigID REST based operations
 * Enhanced with OAuth2 Client Credentials security for service-to-service communication
 */
@Component
public class ControllerAppRestTemplate {
    
    private static final Logger logger = LoggerFactory.getLogger(ControllerAppRestTemplate.class);
    
    @Value("${ssl_error.ignore:}")
    private boolean ignoreSSL;
    
    private final ServiceTokenProvider tokenProvider;

    public ControllerAppRestTemplate(ServiceTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    /**
     * Get call template with endpoint
     * 
     * @param endPoint endpoint of the url
     * @return response entity
     */
    public ResponseEntity<String> get(String baseUrl, String endPoint) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.GET, null, null, null);
    }

    /**
     * Get call template with endpoint and params
     * 
     * @param endPoint endpoint of the url
     * @param params input params for the call
     * @return response entity
     */
    public ResponseEntity<String> get(String baseUrl, String endPoint, Map<String, String> params) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.GET, null, params, null);
    }

    /**
     * Post call template with endpoint
     * 
     * @param endPoint endpoint of the url
     * @return response entity
     */
    public ResponseEntity<String> post(String baseUrl, String endPoint, Object object) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.POST, null, null, object);
    }

    /**
     * Post call template with endpoint and params
     * 
     * @param endPoint endpoint of the url
     * @param params input params for the call
     * @return response entity
     */
    public ResponseEntity<String> post(String baseUrl, String endPoint, Object object, Map<String, String> params) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.POST, null, params, object);
    }

    /**
     * Put call template with endpoint
     * 
     * @param endPoint endpoint of the url
     * @return response entity
     */
    public ResponseEntity<String> put(String baseUrl, String endPoint, Object object) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.PUT, null, null, object);
    }

    /**
     * Put call template with endpoint and params
     * 
     * @param endPoint endpoint of the url
     * @param params input params for the call
     * @return response entity
     */
    public ResponseEntity<String> put(String baseUrl, String endPoint, Object object, Map<String, String> params) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.PUT, null, params, object);
    }

    /**
     * DELETE call template with endpoint
     * 
     * @param endPoint endpoint of the url
     * @return response entity
     */
    public ResponseEntity<String> delete(String baseUrl, String endPoint) throws APIBadRequestException {
        return this.exchange(baseUrl + endPoint, HttpMethod.DELETE, null, null);
    }

    /**
     * method to exchange requests to API
     * 
     * @param targetUrl full Url to communicate to
     * @param httpMethod method to be used
     * @param params input params for the call
     * @param object object for input
     * @return response entity
     */
    private ResponseEntity<String> exchange(String targetUrl, HttpMethod httpMethod, Map<String, String> headers,
                                            Map<String, String> params, Object object) throws APIBadRequestException {
        
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(targetUrl);
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                builder.queryParam(entry.getKey(), entry.getValue());
            }
        }
        
        String url = builder.toUriString();
        url = builder.toUriString().replace("%20", " ");
        logger.info(url);

        try {
            RestTemplate restTemplateEx = new RestTemplate();
            if (ignoreSSL) {
                restTemplateEx.setRequestFactory(this.getRequestFactory());
            }

            HttpHeaders theHeaders = new HttpHeaders();
            if (headers != null) {
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    theHeaders.add(entry.getKey(), entry.getValue());
                }
            }
            theHeaders.setContentType(MediaType.APPLICATION_JSON);

            // ======= OAUTH2 INTEGRATION: Add Bearer Token =======
            // Get OAuth2 access token and add to headers
            String accessToken = tokenProvider.getAccessToken();
            theHeaders.set("Authorization", "Bearer " + accessToken);
            logger.debug("Added OAuth2 Bearer token to request: {} {}", httpMethod, url);
            // ====================================================

            HttpEntity<Object> entity = new HttpEntity<>(object, theHeaders);

            logger.info("{} Request sent to {}", httpMethod, url);
            logger.debug("Header -> {}", theHeaders);
            logger.debug("Object -> {}", object);

            return restTemplateEx.exchange(url, httpMethod, entity, String.class);
            
        } catch (KeyStoreException | NoSuchAlgorithmException | KeyManagementException e) {
            logger.error("Unable to ignore SSL certificate error '*' e.getMessage() + \"'\",e);
            throw new APIConnectionException(APIExceptionType.ControllerApp, "Unable to ignore SSL certificate error", e);
        } catch (ResourceAccessException e) {
            logger.error("Unable to reach server '*' e.getMessage() + \"'\",e);
            throw new APIConnectionException(APIExceptionType.ControllerApp, "Unable to reach server", e);
        } catch (HttpClientErrorException e) {
            HttpStatusCode statusCode = e.getStatusCode();
            if (statusCode == HttpStatus.UNAUTHORIZED) {
                logger.error("Unable to reach server '*' e.getMessage() + \"'\", e);
                throw new APIConnectionException(APIExceptionType.ControllerApp, "Failed to authenticate on server", e);
            } else if (statusCode == HttpStatus.SERVICE_UNAVAILABLE) {
                throw new APIConnectionException(APIExceptionType.ControllerApp, e.getMessage(), e.getResponseBodyAsString(),
                        "Unable to reach server", e);
            } else if (statusCode == HttpStatus.BAD_REQUEST) {
                throw new APIBadRequestException(APIExceptionType.ControllerApp, e.getMessage());
            } else if (statusCode == HttpStatus.NOT_FOUND) {
                throw new APIDataNotFoundException(APIExceptionType.ControllerApp, e.getMessage());
            } else {
                logger.error("Attempt to reach data was rejected by Application with message: '" + e.getMessage() + "\"', e);
                throw new APIConnectionException(APIExceptionType.ControllerApp, "Attempt to reach data was rejected by Application with message: '" + e.getMessage() + "'");
            }
        }
    }

    /**
     * builds and returns request factory for ignoring SSL certificate exception
     * 
     * @return http client request factory with ignored SSL
     * @throws KeyStoreException thrown if the key store fails
     * @throws NoSuchAlgorithmException thrown if no algorithm present
     * @throws KeyManagementException thrown if
     */
    private HttpComponentsClientHttpRequestFactory getRequestFactory()
            throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {

        // Create a TrustAllStrategy to trust all certificates
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial(null, TrustAllStrategy.INSTANCE)
                .build();

        // Create an SSLConnectionSocketFactory with NoopHostnameVerifier
        SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(
                sslContext,
                NoopHostnameVerifier.INSTANCE
        );

        // Build the connection manager with the custom SSLConnectionSocketFactory
        var connectionManager = PoolingHttpClientConnectionManagerBuilder.create()
                .setSSLSocketFactory(sslSocketFactory)
                .setMaxConnTotal(1000) // Maximum total connections
                .setMaxConnPerRoute(100) // Maximum connections per route
                .build();

        // Build the CloseableHttpClient with the connection manager
        CloseableHttpClient httpClient = HttpClients.custom()
                .setConnectionManager(connectionManager)
                .disableAutomaticRetries() // Disable automatic retries
                .build();

        // Create and return the HttpComponentsClientHttpRequestFactory
        return new HttpComponentsClientHttpRequestFactory(httpClient);
    }
}
