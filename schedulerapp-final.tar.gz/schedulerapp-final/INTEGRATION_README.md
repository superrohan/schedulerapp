# OAuth2 Integration for ControllerAppRestTemplate - Final Implementation

## Overview

This is the **exact integration** for your existing `ControllerAppRestTemplate` class. The OAuth2 Bearer token is added directly in the `exchange()` method where headers are built.

## What Changed

### ✅ Only 3 Lines Added to Your Existing Code

In your `ControllerAppRestTemplate.java`, in the `exchange()` method, I added these lines right after `theHeaders.setContentType(MediaType.APPLICATION_JSON);`:

```java
// ======= OAUTH2 INTEGRATION: Add Bearer Token =======
// Get OAuth2 access token and add to headers
String accessToken = tokenProvider.getAccessToken();
theHeaders.set("Authorization", "Bearer " + accessToken);
logger.debug("Added OAuth2 Bearer token to request: {} {}", httpMethod, url);
// ====================================================
```

That's it! Your existing code flow remains exactly the same.

## Complete Modified Method

Here's what the relevant part of your `exchange()` method looks like now:

```java
private ResponseEntity<String> exchange(String targetUrl, HttpMethod httpMethod, Map<String, String> headers,
                                        Map<String, String> params, Object object) throws APIBadRequestException {
    
    // ... your existing URL building code ...
    
    try {
        RestTemplate restTemplateEx = new RestTemplate();
        if (ignoreSSL) {
            restTemplateEx.setRequestFactory(this.getRequestFactory());
        }

        HttpHeaders theHeaders = new HttpHeaders();
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                theHeaders.add(entry.getKey(), entry.getValue());
            }
        }
        theHeaders.setContentType(MediaType.APPLICATION_JSON);

        // ======= NEW: OAuth2 TOKEN =======
        String accessToken = tokenProvider.getAccessToken();
        theHeaders.set("Authorization", "Bearer " + accessToken);
        logger.debug("Added OAuth2 Bearer token to request: {} {}", httpMethod, url);
        // =================================

        HttpEntity<Object> entity = new HttpEntity<>(object, theHeaders);

        logger.info("{} Request sent to {}", httpMethod, url);
        // ... rest of your existing code ...
```

## New Files Added

### 1. ServiceTokenProvider (Autowired in ControllerAppRestTemplate)

```java
@Component
public class ServiceTokenProvider {
    
    private final OAuth2AuthorizedClientManager authorizedClientManager;

    public String getAccessToken() {
        OAuth2AuthorizeRequest authorizeRequest = OAuth2AuthorizeRequest
                .withClientRegistrationId("controllerapp-client")
                .principal("schedulerapp-service")
                .build();

        OAuth2AuthorizedClient authorizedClient = 
            this.authorizedClientManager.authorize(authorizeRequest);

        return authorizedClient.getAccessToken().getTokenValue();
    }
}
```

### 2. OAuthClientConfig

```java
@Configuration
public class OAuthClientConfig {
    
    @Bean
    public OAuth2AuthorizedClientManager authorizedClientManager(
            ClientRegistrationRepository clientRegistrationRepository,
            OAuth2AuthorizedClientService authorizedClientService) {
        
        OAuth2AuthorizedClientProvider authorizedClientProvider = 
            OAuth2AuthorizedClientProviderBuilder.builder()
                .clientCredentials()
                .build();

        AuthorizedClientServiceOAuth2AuthorizedClientManager authorizedClientManager = 
            new AuthorizedClientServiceOAuth2AuthorizedClientManager(
                clientRegistrationRepository, 
                authorizedClientService);

        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        return authorizedClientManager;
    }
}
```

## Configuration

### application.yml

Add this OAuth2 configuration:

```yaml
spring:
  security:
    oauth2:
      client:
        registration:
          controllerapp-client:
            client-id: ${ENTRA_CLIENT_ID}
            client-secret: ${ENTRA_CLIENT_SECRET}
            authorization-grant-type: client_credentials
            scope: api://controller-app/.default
        provider:
          controllerapp-client:
            token-uri: https://login.microsoftonline.com/{your-tenant-id}/oauth2/v2.0/token
```

### pom.xml

Add OAuth2 dependency:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-client</artifactId>
</dependency>
```

## How It Works

### Before (Your Current Flow)
```
ControllerAppRepo calls method
    ↓
ControllerAppRestTemplate.post(baseUrl, endpoint, object)
    ↓
exchange() method
    ↓
Headers: Content-Type: application/json
    ↓
HTTP POST to ControllerApp
NO Authorization header
```

### After (With OAuth2)
```
ControllerAppRepo calls method (NO CHANGES)
    ↓
ControllerAppRestTemplate.post(baseUrl, endpoint, object) (NO CHANGES)
    ↓
exchange() method (3 LINES ADDED)
    ↓
ServiceTokenProvider.getAccessToken()
    ├─ First call: Fetch token from Entra ID
    └─ Subsequent calls: Return cached token
    ↓
Headers: 
    - Content-Type: application/json
    - Authorization: Bearer eyJ0eXAiOiJKV1Qi...  ← NEW
    ↓
HTTP POST to ControllerApp
WITH OAuth2 Bearer token
```

## Setup Steps

### 1. Azure Entra ID Setup

```bash
1. Azure Portal → Entra ID → App Registrations
2. Create "SchedulerApp-Service"
3. Copy Application (client) ID
4. Certificates & Secrets → New client secret → Copy value
5. API Permissions → Add permission → My APIs → ControllerApp
6. Select Application permissions
7. Grant admin consent
```

### 2. Update Environment Variables

```bash
export ENTRA_CLIENT_ID="your-schedulerapp-client-id"
export ENTRA_CLIENT_SECRET="your-client-secret"
```

### 3. Replace ControllerAppRestTemplate.java

Replace your existing `ControllerAppRestTemplate.java` with the modified version that includes:
- Constructor injection of `ServiceTokenProvider`
- 3 lines in `exchange()` method to add OAuth2 token

### 4. Add New Classes

Add these two new classes to your project:
- `config/OAuthClientConfig.java`
- `security/ServiceTokenProvider.java`

### 5. Update application.yml

Add the OAuth2 configuration shown above.

### 6. Update pom.xml

Add the OAuth2 client dependency.

## What Doesn't Change

✅ **ControllerAppRepo** - Zero changes  
✅ **All your endpoint calling methods** - Zero changes  
✅ **Your scheduler jobs** - Zero changes  
✅ **Your existing logging** - Keeps working as-is  
✅ **SSL ignore logic** - Continues to work  
✅ **Error handling** - All your existing exception handling works  

## Example - No Changes to Your Repo

Your `ControllerAppRepo` continues to work exactly as before:

```java
@Repository
public class ControllerAppRepo {
    
    private final ControllerAppRestTemplate controllerAppRestTemplate;
    
    // This method needs ZERO changes
    public String getScansByStatus(String status) {
        Map<String, String> queryStrings = new HashMap<>();
        queryStrings.put("status", status);
        
        // OAuth2 token automatically added inside exchange() method
        ResponseEntity<String> response = 
            controllerAppRestTemplate.get(controllerappBaseUrl, 
                                         recentlyCompletedScansEndpoint, 
                                         queryStrings);
        
        return response.getBody();
    }
    
    // This method needs ZERO changes
    public String launchScanCycle(long scanCycleId) {
        // OAuth2 token automatically added inside exchange() method
        ResponseEntity<String> response = 
            controllerAppRestTemplate.post(controllerappBaseUrl, 
                                          activeScanCyclesEndpoint + "/" + scanCycleId, 
                                          null);
        
        return response.getBody();
    }
}
```

## Verification

Once deployed, check logs:

```
DEBUG c.u.b.s.c.ControllerAppRestTemplate - Added OAuth2 Bearer token to request: POST http://controller-app:8080/controller/internal/scheduler/launch-scan/123
INFO  c.u.b.s.c.ControllerAppRestTemplate - POST Request sent to http://controller-app:8080/controller/internal/scheduler/launch-scan/123
```

## Token Lifecycle

- **First API call**: Token fetched from Entra ID
- **Cached**: Token stored in memory by Spring Security
- **Reused**: Subsequent calls use cached token
- **Auto-refresh**: Spring Security refreshes before expiry
- **You never touch token logic**: All handled automatically

## Troubleshooting

### Issue: "Unable to authorize client"

**Cause**: Invalid client credentials or token URI

**Fix**: Verify in `application.yml`:
- `client-id` matches Entra ID app registration
- `client-secret` is correct (copy from Entra ID)
- `token-uri` has correct tenant ID

### Issue: 401 Unauthorized from ControllerApp

**Cause**: ControllerApp not validating JWT

**Fix**: ControllerApp needs this configuration:

```yaml
spring:
  security:
    oauth2:
      resourceserver:
        jwt:
          issuer-uri: https://login.microsoftonline.com/{tenant-id}/v2.0
          audiences: api://controller-app
```

### Issue: Token not being added

**Cause**: `ServiceTokenProvider` not autowired

**Fix**: Ensure:
1. `@Component` annotation on `ServiceTokenProvider`
2. Constructor injection in `ControllerAppRestTemplate`:
   ```java
   private final ServiceTokenProvider tokenProvider;
   
   public ControllerAppRestTemplate(ServiceTokenProvider tokenProvider) {
       this.tokenProvider = tokenProvider;
   }
   ```

### Enable Debug Logging

```yaml
logging:
  level:
    com.ubs.bigid.schedulerapp: DEBUG
    org.springframework.security.oauth2: DEBUG
```

## Summary

**What you need to change:**
1. ✏️ Modify `ControllerAppRestTemplate.java` - Add constructor + 3 lines in `exchange()` method
2. ➕ Add `ServiceTokenProvider.java` - New file
3. ➕ Add `OAuthClientConfig.java` - New file
4. ⚙️ Update `application.yml` - Add OAuth2 config
5. 📦 Update `pom.xml` - Add OAuth2 dependency

**What stays the same:**
- ✅ All your `ControllerAppRepo` methods
- ✅ All your scheduler jobs
- ✅ All your existing logging
- ✅ All your error handling
- ✅ SSL ignore functionality

The OAuth2 security is transparently added in the existing `exchange()` method where all HTTP requests go through!
